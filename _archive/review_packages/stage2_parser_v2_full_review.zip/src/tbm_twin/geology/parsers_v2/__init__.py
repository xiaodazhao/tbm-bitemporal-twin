"""Stage 2 Geological Parser V2 package.

V2 is intentionally parallel to the existing Stage 2 parser. Importing this
package does not switch the production raw-geology pipeline.
"""

from tbm_twin.geology.parsers_v2.registry import parse_pdf_v2, parser_for_source

__all__ = ["parse_pdf_v2", "parser_for_source"]
