# ruff: noqa: RUF001
"""FaceSketch table parser."""

from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import Any

from tbm_twin.geology.table_parser_v2.models import (
    EpistemicStatus,
    ParsedDocument,
    PrimaryEvidenceType,
    SourceType,
    SpatialKind,
    SpatialScope,
    TableParserEvidence,
    TableParserResult,
    TemplateSignature,
    TemporalMetadata,
)
from tbm_twin.geology.table_parser_v2.pdf_tables import ExtractedCell, ExtractedPage, ExtractedTable
from tbm_twin.geology.table_parser_v2.provenance import make_table_cell_span
from tbm_twin.geology.table_parser_v2.text_utils import (
    CHAINAGE_RE,
    compact_text,
    first_local_date,
    first_match,
    normalize_text,
    parse_chainage_value,
)

CHECK_MARK = "√"
GEOLOGY_ROW_LABEL = "地质描述"

LITHOLOGY_TERMS = (
    "板岩夹变质砂岩",
    "板岩夹砂岩",
    "板岩",
    "变质砂岩",
)
WEATHERING_TERMS = ("弱风化", "微风化", "强风化", "全风化", "未风化")
JOINT_TERMS = ("节理裂隙发育密集", "节理裂隙较发育", "节理裂隙发育", "节理发育")
ROCK_MASS_TERMS = ("岩体破碎-极破碎", "岩体较破碎", "岩体破碎", "岩体极破碎")
STABILITY_TERMS = ("自稳性较差", "稳定性较差", "稳定性一般", "稳定性差")
WATER_TERMS = (
    "滴渗水-线状出水",
    "线-股状出水",
    "渗滴水",
    "线状出水",
    "股状出水",
    "突涌水",
    "喷出",
    "滴渗水",
    "偶有渗水",
    "湿润",
    "无水",
)
BLOCK_FALL_TERMS = ("轻微掉块", "掉块", "坍塌", "溜坍")
RISK_TERMS = ("掉块", "坍塌", "失稳", "变形", "出水", "卡机")


def parse_face_sketch(
    pdf_path: Path,
    pages: list[ExtractedPage],
    template_signature: TemplateSignature,
) -> TableParserResult:
    """Parse a FaceSketch PDF from its main pdfplumber table."""

    main_table = _find_main_table(pages)
    if main_table is None:
        document = ParsedDocument(
            source_pdf_path=pdf_path,
            source_type=SourceType.FACE_SKETCH,
            report_id=None,
            document_spatial_scope=None,
            face_chainage=None,
            temporal=TemporalMetadata(),
            template_signature=template_signature,
            parse_warnings=["UNSUPPORTED_TEMPLATE"],
        )
        return TableParserResult(document=document, primary_evidence=[])

    table_text = main_table.joined_text()
    face_chainage = parse_chainage_value(table_text) or parse_chainage_value(pdf_path.name)
    scope = SpatialScope(
        kind=SpatialKind.POINT,
        start_chainage=face_chainage or 0.0,
        end_chainage=face_chainage or 0.0,
        raw_expression=_first_chainage_raw(table_text),
        basis="face_sketch_table_text",
    )
    row_by_label = _rows_by_label(main_table)
    checked = _checked_options(main_table)
    description_cells = _row_cells(row_by_label.get(GEOLOGY_ROW_LABEL, []))
    description = " ".join(cell.text for cell in description_cells)
    description_span_ids: list[str] = []
    spans = []
    for cell in _selected_cells(main_table, checked) + description_cells:
        span = make_table_cell_span(cell, _cell_role(cell, row_by_label))
        if span.span_id not in description_span_ids:
            spans.append(span)
            if cell in description_cells:
                description_span_ids.append(span.span_id)

    form_water = _water_from_form(checked)
    narrative_water = _extract_water_observation(description)
    attributes: dict[str, Any] = {
        "face_state": _first_checked(checked, "掌子面状态"),
        "excavated_face_state": _first_checked(checked, "毛开挖面状态"),
        "rock_strength": _first_checked(checked, "岩石强度"),
        "weathering": _first_checked(checked, "风化程度")
        or first_match(WEATHERING_TERMS, description),
        "joint_spacing": _first_checked(checked, "间距"),
        "joint_extension": _first_checked(checked, "延伸性"),
        "joint_roughness": _first_checked(checked, "粗糙度"),
        "joint_aperture": _first_checked(checked, "张开性"),
        "karst_development": _first_checked(checked, "岩溶发育程度"),
        "design_surrounding_rock_grade": _grade_from_row(row_by_label.get("设计围岩级别", []), 1),
        "suggested_surrounding_rock_grade": _grade_from_row(
            row_by_label.get("设计围岩级别", []), -1
        ),
        "lithology": first_match(LITHOLOGY_TERMS, description),
        "joint_development": first_match(JOINT_TERMS, description),
        "rock_mass_state": first_match(ROCK_MASS_TERMS, description),
        "stability": first_match(STABILITY_TERMS, description),
        "block_fall_or_collapse": first_match(BLOCK_FALL_TERMS, description),
        "form_water_status": form_water["selected"],
        "form_water_other_raw": _water_other(row_by_label.get("涌水状态", [])),
        "narrative_water_observation": narrative_water,
        "water_type": narrative_water or form_water["selected"],
        "water_status_conflict": bool(
            form_water["selected"] and narrative_water and form_water["selected"] != narrative_water
        ),
        "anomaly_level": _actual_anomaly_level(description),
        "source_risk_text": _risk_sentences(description),
        "forecast_qualifiers": None,
    }
    field_spans = {
        key: [span.span_id for span in spans] for key in attributes if attributes[key] is not None
    }
    evidence = TableParserEvidence(
        evidence_id=_evidence_id(pdf_path, "face", scope.raw_expression),
        evidence_type=PrimaryEvidenceType.FACE_OBSERVATION,
        epistemic_status=EpistemicStatus.OBSERVED,
        spatial_scope=scope,
        source_spans=spans,
        field_spans=field_spans,
        assembled_text=description,
        attributes=attributes,
    )
    temporal = TemporalMetadata(
        observed_local_date=first_local_date(table_text),
        document_local_date=first_local_date(table_text),
        available_local_date=first_local_date(table_text),
        available_basis="form_date",
    )
    document = ParsedDocument(
        source_pdf_path=pdf_path,
        source_type=SourceType.FACE_SKETCH,
        report_id=_report_id(pdf_path.name),
        document_spatial_scope=scope,
        face_chainage=face_chainage,
        temporal=temporal,
        template_signature=template_signature,
    )
    return TableParserResult(document=document, primary_evidence=[evidence])


def _find_main_table(pages: list[ExtractedPage]) -> ExtractedTable | None:
    for page in pages:
        for table in page.tables:
            text = compact_text(table.joined_text())
            if "掌子面状态" in text and "地质描述" in text:
                return table
    return None


def _row_text(row: list[ExtractedCell | None]) -> str:
    return normalize_text(" ".join(cell.text for cell in row if cell is not None))


def _rows_by_label(table: ExtractedTable) -> dict[str, list[ExtractedCell | None]]:
    labels: dict[str, list[ExtractedCell | None]] = {}
    active_structure = False
    for row in table.rows:
        text = compact_text(_row_text(row))
        if "地质结构面" in text:
            active_structure = True
        if text.startswith("7") or "涌水状态" in text:
            active_structure = False
        if "掌子面状态" in text:
            labels["掌子面状态"] = row
        elif "毛开挖面状态" in text:
            labels["毛开挖面状态"] = row
        elif "岩石强度" in text:
            labels["岩石强度"] = row
        elif "风化程度" in text:
            labels["风化程度"] = row
        elif "涌水状态" in text:
            labels["涌水状态"] = row
        elif "岩溶发育程度" in text:
            labels["岩溶发育程度"] = row
        elif "设计围岩级别" in text:
            labels["设计围岩级别"] = row
        elif "地质描述" in text:
            labels[GEOLOGY_ROW_LABEL] = row
        elif active_structure and "间距" in text:
            labels["间距"] = row
        elif active_structure and "延伸性" in text:
            labels["延伸性"] = row
        elif active_structure and "粗糙度" in text:
            labels["粗糙度"] = row
        elif active_structure and "张开性" in text:
            labels["张开性"] = row
    return labels


def _checked_options(table: ExtractedTable) -> dict[str, list[ExtractedCell]]:
    labels = _rows_by_label(table)
    checked: dict[str, list[ExtractedCell]] = {}
    for label, row in labels.items():
        options = [cell for cell in row if cell is not None and CHECK_MARK in cell.text]
        if options:
            checked[label] = options
    return checked


def _clean_option(text: str) -> str:
    cleaned = normalize_text(text).replace(CHECK_MARK, "")
    cleaned = re.sub(r"^[<＜]?\d+(?:～\d+)?", "", cleaned).strip()
    return cleaned


def _first_checked(checked: dict[str, list[ExtractedCell]], label: str) -> str | None:
    cells = checked.get(label, [])
    return _clean_option(cells[0].text) if cells else None


def _water_from_form(checked: dict[str, list[ExtractedCell]]) -> dict[str, str | None]:
    value = _first_checked(checked, "涌水状态")
    other = None
    for cell in checked.get("涌水状态", []):
        match = re.search(r"其它\s*[:：]?\s*(\S+)", cell.text)
        if match:
            other = match.group(1)
    return {"selected": value, "other": other}


def _water_other(row: list[ExtractedCell | None]) -> str | None:
    for cell in row:
        if cell is None:
            continue
        match = re.search(r"其它\s*[:：]?\s*(\S+)", normalize_text(cell.text))
        if match:
            return match.group(1)
    return None


def _row_cells(row: list[ExtractedCell | None]) -> list[ExtractedCell]:
    return [cell for cell in row if cell is not None and normalize_text(cell.text)]


def _selected_cells(
    table: ExtractedTable,
    checked: dict[str, list[ExtractedCell]],
) -> list[ExtractedCell]:
    cells = [cell for values in checked.values() for cell in values]
    for row in table.rows:
        text = compact_text(_row_text(row))
        if "设计围岩级别" in text:
            cells.extend(_row_cells(row))
    return cells


def _cell_role(cell: ExtractedCell, rows_by_label: dict[str, list[ExtractedCell | None]]) -> str:
    for label, row in rows_by_label.items():
        if cell in row:
            return label
    return "table_cell"


def _grade_from_row(row: list[ExtractedCell | None], direction: int) -> str | None:
    candidates = [
        normalize_text(cell.text)
        for cell in row
        if cell is not None and re.fullmatch(r"[ⅠⅡⅢⅣⅤVI]+", normalize_text(cell.text))
    ]
    if not candidates:
        return None
    value = candidates[0] if direction > 0 else candidates[-1]
    return f"{value}级"


def _extract_water_observation(text: str) -> str | None:
    matches = []
    compact = compact_text(text)
    for term in WATER_TERMS:
        if compact_text(term) in compact:
            matches.append(term)
    if not matches:
        return None
    return "；".join(sorted(set(matches), key=lambda value: compact.find(compact_text(value))))


def _actual_anomaly_level(text: str) -> str:
    compact = compact_text(text)
    advisory_only = "如有异常及时上报" in compact and not re.search(
        r"异常[带区体]|反射异常", compact
    )
    if advisory_only:
        return "NONE"
    if re.search(r"(发现|存在|见).{0,12}异常[带区体状态]", compact):
        return "PRESENT"
    return "NONE"


def _risk_sentences(text: str) -> list[str]:
    sentences = re.split(r"[。；;]", normalize_text(text))
    return [
        sentence.strip()
        for sentence in sentences
        if any(term in sentence for term in RISK_TERMS) and "如有异常及时上报" not in sentence
    ]


def _first_chainage_raw(text: str) -> str:
    match = re.search(CHAINAGE_RE, text)
    return match.group(0) if match else ""


def _report_id(filename: str) -> str | None:
    return filename.rsplit(".", maxsplit=1)[0] or None


def _evidence_id(path: Path, kind: str, raw_scope: str) -> str:
    digest = hashlib.sha1(f"{path.name}|{kind}|{raw_scope}".encode()).hexdigest()
    return f"tblv2_{digest[:16]}"
