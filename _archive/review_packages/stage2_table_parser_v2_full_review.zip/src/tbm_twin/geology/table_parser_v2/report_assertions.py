# ruff: noqa: RUF001
"""Generic TSP report assertion parsing and conflict checks."""

from __future__ import annotations

import hashlib
import re
from pathlib import Path
from typing import Any

from tbm_twin.geology.table_parser_v2.models import (
    ReportAssertion,
    SourceSpan,
    SpatialKind,
    SpatialScope,
    TableParserEvidence,
)
from tbm_twin.geology.table_parser_v2.provenance import make_text_block_span
from tbm_twin.geology.table_parser_v2.text_utils import (
    compact_text,
    normalize_text,
    parse_all_chainage_intervals,
)


def parse_tsp_report_assertions(
    pdf_path: Path,
    page_texts: list[str],
    table_evidence: list[TableParserEvidence],
) -> list[ReportAssertion]:
    """Parse report-level grade, water, and block-fall assertions from chapter 7."""

    chapter_page, chapter = _chapter_7_text(page_texts)
    if chapter_page is None or chapter is None:
        return []
    spans = [
        make_text_block_span(
            page_number=chapter_page,
            page_text=page_texts[chapter_page - 1],
            raw_text=chapter,
            source_role="chapter_7_conclusion",
        )
    ]
    assertions: list[ReportAssertion] = []
    assertions.extend(_grade_assertions(pdf_path, chapter, spans, table_evidence))
    assertions.extend(_block_fall_assertions(pdf_path, chapter, spans, table_evidence))
    assertions.extend(_water_assertions(pdf_path, chapter, spans, table_evidence))
    return assertions


def _chapter_7_text(page_texts: list[str]) -> tuple[int | None, str | None]:
    for index, page_text in enumerate(page_texts, start=1):
        compact = compact_text(page_text)
        if "7结论" not in compact or "得出以下结论" not in compact:
            continue
        start = compact.find("7结论")
        raw = normalize_text(page_text)
        marker_index = raw.find("7 结论")
        chapter = raw[marker_index if marker_index >= 0 else start :]
        end_match = re.search(r"\b8\s*附图\b|附图", chapter)
        if end_match:
            chapter = chapter[: end_match.start()]
        return index, chapter
    return None, None


def _grade_assertions(
    pdf_path: Path,
    text: str,
    spans: list[SourceSpan],
    table_evidence: list[TableParserEvidence],
) -> list[ReportAssertion]:
    assertions = []
    for sentence in _sentences(text):
        if "建议按" not in sentence or "围岩施工" not in sentence:
            continue
        intervals = parse_all_chainage_intervals(sentence)
        for index, (raw, start, end) in enumerate(intervals):
            current_start = sentence.find(raw)
            next_start = (
                sentence.find(intervals[index + 1][0])
                if index + 1 < len(intervals)
                else len(sentence)
            )
            local_text = sentence[current_start:next_start]
            match = re.search(r"建议按\s*([ⅠⅡⅢⅣⅤVI]+)\s*级围岩施工", local_text)
            if match is None:
                continue
            attributes = {"suggested_grade": f"{match.group(1)}级"}
            assertions.append(
                _assertion(
                    pdf_path,
                    "GRADE_SUMMARY",
                    raw,
                    start,
                    end,
                    local_text,
                    spans,
                    attributes,
                    table_evidence,
                )
            )
    return assertions


def _block_fall_assertions(
    pdf_path: Path,
    text: str,
    spans: list[SourceSpan],
    table_evidence: list[TableParserEvidence],
) -> list[ReportAssertion]:
    assertions = []
    for paragraph in _numbered_paragraphs(text):
        if not any(term in paragraph for term in ["掉块风险", "溜坍风险", "坍塌风险"]):
            continue
        for raw, start, end in parse_all_chainage_intervals(paragraph):
            attributes = {"block_fall_or_collapse": "掉块风险"}
            assertions.append(
                _assertion(
                    pdf_path,
                    "BLOCK_FALL_SUMMARY",
                    raw,
                    start,
                    end,
                    paragraph,
                    spans,
                    attributes,
                    table_evidence,
                )
            )
    return assertions


def _water_assertions(
    pdf_path: Path,
    text: str,
    spans: list[SourceSpan],
    table_evidence: list[TableParserEvidence],
) -> list[ReportAssertion]:
    assertions = []
    for sentence in _sentences(text):
        if "出水" not in sentence and "渗水" not in sentence:
            continue
        intervals = parse_all_chainage_intervals(sentence)
        for index, (raw, start, end) in enumerate(intervals):
            next_start = (
                sentence.find(intervals[index + 1][0])
                if index + 1 < len(intervals)
                else len(sentence)
            )
            local_text = sentence[sentence.find(raw) : next_start]
            water = _water_type(local_text) or _water_type(sentence)
            if water is None:
                continue
            attributes = {"water_type": water}
            assertions.append(
                _assertion(
                    pdf_path,
                    "WATER_SUMMARY",
                    raw,
                    start,
                    end,
                    sentence,
                    spans,
                    attributes,
                    table_evidence,
                )
            )
    return assertions


def _assertion(
    pdf_path: Path,
    assertion_type: str,
    raw_scope: str,
    start: float,
    end: float,
    raw_text: str,
    spans: list[SourceSpan],
    attributes: dict[str, Any],
    table_evidence: list[TableParserEvidence],
) -> ReportAssertion:
    scope = SpatialScope(
        kind=SpatialKind.INTERVAL,
        start_chainage=start,
        end_chainage=end,
        raw_expression=raw_scope,
        basis="tsp_chapter_7_assertion",
    )
    derived = [item.evidence_id for item in table_evidence if _overlaps(item.spatial_scope, scope)]
    status, details = _consistency(attributes, derived, table_evidence)
    return ReportAssertion(
        assertion_id=_assertion_id(pdf_path, assertion_type, raw_scope, raw_text),
        assertion_type=assertion_type,
        spatial_scope=scope,
        raw_text=normalize_text(raw_text),
        source_spans=spans,
        attributes=attributes,
        derived_from_evidence_ids=derived,
        consistency_status=status,
        conflict_details=details,
    )


def _consistency(
    attributes: dict[str, Any],
    evidence_ids: list[str],
    table_evidence: list[TableParserEvidence],
) -> tuple[str, list[str]]:
    evidence_by_id = {item.evidence_id: item for item in table_evidence}
    details: list[str] = []
    for evidence_id in evidence_ids:
        evidence = evidence_by_id[evidence_id]
        for key, value in attributes.items():
            table_value = evidence.attributes.get(key)
            if table_value is not None and value is not None and table_value != value:
                details.append(f"table {key}={table_value}; summary {key}={value}")
    if details:
        return "CONFLICT", details
    if evidence_ids:
        return "CONSISTENT", details
    return "NO_TABLE_COVERAGE", details


def _overlaps(source: SpatialScope, target: SpatialScope) -> bool:
    return (
        source.start_chainage <= target.end_chainage - 0.2
        and source.end_chainage >= target.start_chainage + 0.2
    )


def _sentences(text: str) -> list[str]:
    return [part.strip() for part in re.split(r"[。；;]", normalize_text(text)) if part.strip()]


def _numbered_paragraphs(text: str) -> list[str]:
    parts = re.split(r"(?=（\d+）)", normalize_text(text))
    return [part.strip() for part in parts if part.strip()]


def _water_type(text: str) -> str | None:
    terms = (
        "滴渗水-线状出水",
        "线-股状出水",
        "线状出水",
        "股状出水",
        "突涌水",
        "滴渗水",
        "偶有渗水",
    )
    compact = compact_text(text)
    for term in terms:
        if compact_text(term) in compact:
            return term
    return None


def _assertion_id(pdf_path: Path, assertion_type: str, raw_scope: str, raw_text: str) -> str:
    digest = hashlib.sha1(
        f"{pdf_path.name}|{assertion_type}|{raw_scope}|{raw_text}".encode()
    ).hexdigest()
    return f"assert_{digest[:16]}"
