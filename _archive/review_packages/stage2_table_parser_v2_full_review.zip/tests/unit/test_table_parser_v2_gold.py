from __future__ import annotations

import hashlib
import json
import re
import shutil
from dataclasses import asdict
from pathlib import Path
from typing import Any

import pdfplumber

from tbm_twin.geology.table_parser_v2 import parse_pdf_v2
from tbm_twin.geology.table_parser_v2.models import PrimaryEvidenceType
from tbm_twin.geology.table_parser_v2.text_utils import compact_text

FIXTURES = Path(__file__).resolve().parents[1] / "fixtures" / "geology_pdfs"
MANUAL_GOLD = Path(__file__).resolve().parents[1] / "manual_gold" / "geology"


def _load_gold(name: str) -> dict[str, Any]:
    return json.loads((MANUAL_GOLD / name).read_text(encoding="utf-8"))


def _hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _forecast_segments(result: Any) -> list[Any]:
    return [
        item
        for item in result.primary_evidence
        if item.evidence_type == PrimaryEvidenceType.FORECAST_SEGMENT
    ]


def _ranges(result: Any) -> list[list[float]]:
    return [
        [item.spatial_scope.start_chainage, item.spatial_scope.end_chainage]
        for item in _forecast_segments(result)
    ]


def test_manual_gold_files_are_not_written_by_parser() -> None:
    gold_paths = sorted(MANUAL_GOLD.glob("*.json"))
    before = {path: (path.stat().st_mtime_ns, _hash(path)) for path in gold_paths}
    for fixture in [
        FIXTURES / "sketch_dyk1013_184_2.pdf",
        FIXTURES / "hsp_dyk1013_190_2.pdf",
        FIXTURES / "tsp_dyk1013_080_2.pdf",
    ]:
        parse_pdf_v2(fixture)
    after = {path: (path.stat().st_mtime_ns, _hash(path)) for path in gold_paths}
    assert after == before


def test_sketch_manual_gold_from_real_pdf() -> None:
    gold = _load_gold("sketch_dyk1013_184_2.json")
    result = parse_pdf_v2(FIXTURES / "sketch_dyk1013_184_2.pdf")

    assert result.document.source_type == gold["source_type"]
    assert result.document.face_chainage == gold["document_metadata"]["face_chainage"]
    assert (
        result.document.temporal.observed_local_date
        == gold["document_metadata"]["observed_local_date"]
    )
    assert len(result.primary_evidence) == 1
    evidence = result.primary_evidence[0]
    assert evidence.evidence_type == gold["primary_evidence"][0]["type"]
    assert (
        evidence.spatial_scope.start_chainage
        == gold["primary_evidence"][0]["spatial_scope"]["start_chainage"]
    )
    for key, expected in gold["primary_evidence"][0]["expected_attributes"].items():
        assert evidence.attributes[key] == expected


def test_hsp_manual_gold_from_real_pdf() -> None:
    gold = _load_gold("hsp_dyk1013_190_2.json")
    result = parse_pdf_v2(FIXTURES / "hsp_dyk1013_190_2.pdf")

    assert result.document.source_type == gold["source_type"]
    assert result.document.face_chainage == gold["document_metadata"]["face_chainage"]
    assert (
        result.document.temporal.observed_local_date
        == gold["document_metadata"]["observed_local_date"]
    )
    assert (
        result.document.temporal.document_local_date
        == gold["document_metadata"]["document_local_date"]
    )
    assert len(result.primary_evidence) == gold["primary_evidence_count"]
    assert _ranges(result) == [item["range"] for item in gold["forecast_segments"]]
    for evidence, expected in zip(
        _forecast_segments(result), gold["forecast_segments"], strict=True
    ):
        assert evidence.attributes["anomaly_level"] == expected["anomaly_level"]
        assert evidence.attributes["suggested_grade"] == expected["suggested_grade"]
        if "risk_points" in expected:
            assert evidence.attributes["risk_points"] == expected["risk_points"]


def test_tsp_manual_gold_from_real_pdf() -> None:
    gold = _load_gold("tsp_dyk1013_080_2.json")
    result = parse_pdf_v2(FIXTURES / "tsp_dyk1013_080_2.pdf")

    assert result.document.source_type == gold["source_type"]
    assert result.document.face_chainage == gold["document_metadata"]["face_chainage"]
    assert (
        result.document.temporal.observed_local_date
        == gold["document_metadata"]["observed_local_date"]
    )
    assert (
        result.document.temporal.document_local_date
        == gold["document_metadata"]["document_local_date"]
    )
    assert len(result.primary_evidence) == gold["primary_evidence_count"]
    assert _ranges(result) == [item["range"] for item in gold["forecast_segments"]]
    for evidence, expected in zip(
        _forecast_segments(result), gold["forecast_segments"], strict=True
    ):
        for key, value in expected.items():
            if key != "range":
                assert evidence.attributes[key] == value
    assert len(result.report_assertions) == gold["report_assertion_count"]
    conflict_gold = gold["required_report_assertions"][0]
    conflict = next(
        assertion
        for assertion in result.report_assertions
        if assertion.assertion_type == conflict_gold["type"]
        and assertion.spatial_scope.start_chainage == conflict_gold["range"][0]
        and assertion.spatial_scope.end_chainage == conflict_gold["range"][1]
    )
    assert conflict.attributes["suggested_grade"] == conflict_gold["suggested_grade"]
    assert conflict.consistency_status == conflict_gold["consistency_status"]
    assert conflict_gold["conflict_contains"] in conflict.conflict_details


def test_source_spans_have_real_bbox_and_crop_text() -> None:
    for fixture in [
        FIXTURES / "sketch_dyk1013_184_2.pdf",
        FIXTURES / "hsp_dyk1013_190_2.pdf",
        FIXTURES / "tsp_dyk1013_080_2.pdf",
    ]:
        result = parse_pdf_v2(fixture)
        with pdfplumber.open(fixture) as pdf:
            for record in [*result.primary_evidence, *result.report_assertions]:
                for span in record.source_spans:
                    assert span.bbox != (0.0, 0.0, 0.0, 0.0)
                    if span.extraction_method != "pdfplumber_table_cell":
                        continue
                    assert span.has_real_bbox
                    assert span.bbox is not None
                    crop_text = pdf.pages[span.page_number - 1].crop(span.bbox).extract_text() or ""
                    assert compact_text(crop_text)
                    assert _has_text_overlap(crop_text, span.raw_text)


def test_content_detection_survives_copy_to_arbitrary_folder(tmp_path: Path) -> None:
    for fixture in [
        FIXTURES / "sketch_dyk1013_184_2.pdf",
        FIXTURES / "hsp_dyk1013_190_2.pdf",
        FIXTURES / "tsp_dyk1013_080_2.pdf",
    ]:
        copied = tmp_path / f"renamed_{fixture.name}"
        shutil.copy2(fixture, copied)
        result = parse_pdf_v2(copied)
        assert result.document.source_type != "UNSUPPORTED"
        assert result.primary_evidence


def test_src_has_no_sample_hardcoding_or_gold_dependency() -> None:
    src_root = Path("src/tbm_twin/geology/table_parser_v2")
    combined = "\n".join(path.read_text(encoding="utf-8") for path in src_root.glob("*.py"))
    assert "tests/manual_gold" not in combined
    assert "tests/gold" not in combined
    forbidden = ["DyK1013+184.2", "DyK1013+080.2", "DyK1013+190.2", "1013182.0"]
    assert not any(token in combined for token in forbidden)


def test_non_gold_generalization_real_pdfs() -> None:
    samples = [
        FIXTURES / "non_gold_sketch_two_page.pdf",
        FIXTURES / "non_gold_hsp_13_page.pdf",
        FIXTURES / "non_gold_tsp_21_page.pdf",
        FIXTURES / "non_gold_hsp_non1013.pdf",
    ]
    for sample in samples:
        result = parse_pdf_v2(sample)
        assert not result.document.parse_warnings
        assert result.document.template_signature.status == "SUPPORTED"
        assert result.primary_evidence
        assert not _has_header_evidence(result)
        for evidence in result.primary_evidence:
            assert evidence.source_spans
            for span in evidence.source_spans:
                if span.extraction_method == "pdfplumber_table_cell":
                    assert span.has_real_bbox
        ranges = _ranges(result)
        if ranges:
            assert all(start < end for start, end in ranges)
            assert ranges == sorted(ranges)


def _has_text_overlap(left: str, right: str) -> bool:
    left_compact = compact_text(left)
    right_compact = compact_text(right)
    if left_compact in right_compact or right_compact in left_compact:
        return True
    left_tokens = set(re.findall(r"[\u4e00-\u9fffA-Za-z0-9.]+", left_compact))
    right_tokens = set(re.findall(r"[\u4e00-\u9fffA-Za-z0-9.]+", right_compact))
    return bool(left_tokens & right_tokens)


def _has_header_evidence(result: Any) -> bool:
    dumped = json.dumps([asdict(item) for item in result.primary_evidence], ensure_ascii=False)
    return "里程范围、本次预报结论、物探探测结果、风险提示、建议围岩等级" in dumped
