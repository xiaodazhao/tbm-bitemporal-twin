# Stage 2 Table Parser V2 Implementation Report

- Scope: new pdfplumber-backed table parsing kernel only.
- Prototype status: `src/tbm_twin/geology/parsers_v2/` marked `prototype_text_parser` and retained for audit.
- New package: `src/tbm_twin/geology/table_parser_v2/`.
- pdfplumber version: `0.11.10`.
- Manual Gold samples: Sketch PASS, HSP PASS, TSP PASS.
- Non-Gold structural samples: 4 PASS.
- Table-cell SourceSpan bbox pass rate: 182/182.
- Zero bbox spans: 0.
- Parser does not write `tests/manual_gold/geology` and source search found: NONE forbidden token matches.
- Full pipeline migration, Applicability recompute, Gold expansion, and Stage 3 were not run.
