# Stage 2 Raw Geology Validation

Raw PDFs are the formal geological input. The legacy database is used only for comparison.

- raw PDF count: 227
- in-scope asset count: 225
- duplicate asset count: 2
- out-of-scope asset count: 2
- parsed document count: 223
- canonical geological evidence count: 824
- source type documents: {'FACE_SKETCH': 167, 'SONIC_FORECAST': 49, 'TSP_REPORT': 7}
- source type evidence: {'SONIC_FORECAST': 408, 'FACE_SKETCH': 240, 'TSP_REPORT': 176}
- evidence epistemic distribution: {'FORECAST': 464, 'OBSERVED': 297, 'BACKGROUND': 63}
- cover metadata excluded count: 57
- temporal local date consistency ratio: 1.000000
- forecast face_chainage validation: {'WITHIN_FORECAST_SCOPE': 53, 'UNKNOWN': 3}
- provenance consistency: {'provenance_consistency_count': 824, 'provenance_consistency_total': 824, 'provenance_consistency_ratio': 1.0}
- warning propagation before/after: {'legacy_style_warning_pollution_candidate_count': 353, 'post_fix_warning_pollution_count': 0}
- invalid spatial evidence count: 52
- applicability result distribution: {'NOT_APPLICABLE': 16097, 'APPLICABLE_WITH_QUALIFICATION': 383}
- applicability temporal distribution: {'NOT_YET_AVAILABLE': 12002, 'AVAILABLE': 4466, 'UNKNOWN_WITHIN_PRECISION': 12}
- real future leakage check: {'non_not_applicable_future_leakage_count': 0}
- documents with available_time_extent: 223
- same-day temporal uncertainty assignments: 12
- legacy evidence count: 484